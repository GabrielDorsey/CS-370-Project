import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;

public class clientSide extends JFrame{
    private JPanel mainPanel;
    private JTextField textBox;
    private JButton sendButton;
    private  JTextArea chatArea;
    private JButton sendFileButton;
    private  static Socket socket;
    private static InputStreamReader inStream;
    private  static BufferedWriter buffWriter;
    private static  BufferedReader buffReader;
    private static DataOutputStream dataOutputStream;
    private static DataInputStream dataInputStream;





    /**
     * @param title gets the title so that the frame can update it when the program is ran.
     *              Function: Creates the server side UI to be used throughout the program
     *
     */
    public clientSide(String title){
        super(title); //gets the title of the frame
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setContentPane(mainPanel);
        this.pack();

        //when the send button is pressed, retreive the message that was in the text box and send the message.
        sendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String message = textBox.getText();
                if(!message.isEmpty()){

                    chatArea.setText(chatArea.getText().trim()+ "\n Client:\t" + message );
                    sendMessage(message);

                }
                else {
                    System.out.println("Could not retrieve");
                }
            }
        });

        //After Typing in the name of the file that is in the Files folder, hit the Send File button
        sendFileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String fileName = textBox.getText();
                //if text field isn't empty
                if(!fileName.isEmpty()){
                    try {
                        //Gets the current directory path
                        String dir = System.getProperty("user.dir");
                        dir = (dir + "/Files/");
                        //Check if there is a file with the name provided
                        if(Files.exists(Path.of((dir+fileName)))){
                            //Sends a message to let the server know a file is being sent
                            sendMessage("Attempting File Upload");
                            //Provides the fileName so that the server can create its own file using the same name
                            sendMessage(fileName);

                            //If the File Send is successful, Send a confirmation message to the client
                            if(sendFile(fileName)){
                                chatArea.setText(chatArea.getText().trim()+ "\n Client:\t" + fileName + " uploading..." );
                                //System.out.println(fileName);
                            }
                        }
                        else{
                            //If the File does not exist in the folder, inform client
                            chatArea.setText(chatArea.getText().trim() + "\n ClientSide Error: " + "File with name " + fileName + " does not exist.");
                        }

                    } catch (Exception ex) {
                        throw new RuntimeException(ex);
                    }
                }
            }
        });
    }



    /**
     * Method: sendMessage
     * Function: Sends a message to the client
     * @param message : Message to send to the client
     */
    public void sendMessage(String message){
        try{
            buffWriter.write(message);
            buffWriter.newLine();
            buffWriter.flush();

        }catch(IOException e) {
            e.printStackTrace();
            System.out.println("Could Not Send Message.");
        }
    }


    /**
     * Method: sendFile
     * Function: Finds file in folder using the FileName provided, gets File Length,
     *           Breaks file up and sends it across the outputStream
     * @param fileName
     * @return
     * @throws Exception
     */
    private boolean sendFile(String fileName) throws Exception{
        //Gets the directory
        String dir = System.getProperty("user.dir");
        dir = (dir + "/Files/");
        int bytes = 0;
        try{
            //Creates File from the file at the path
            File file = new File(dir + fileName);
            FileInputStream fileInputStream = new FileInputStream(file);
            //Get the File size and send it through the output stream
            dataOutputStream.writeLong(file.length());
            //Break the file into chunks, This is just in case the txt file being sent is too large to be sent through in
            //  one go.
            byte[] buffer = new byte[4*1024];
            while ((bytes=fileInputStream.read(buffer))!=-1){
                dataOutputStream.write(buffer,0,bytes);
                dataOutputStream.flush();
            }
            fileInputStream.close();
            return true;
        }
        catch (FileNotFoundException f){
            //f.printStackTrace();

            chatArea.setText(chatArea.getText().trim()+ "\n ClientSide Error:\t" + "Could not find File with name: " + fileName );
            return false;
        }


    }
    /**
     * Method: closeConnection
     * Function: Closes the connection of all the thing that the server uses, and throws and exception if it does not work
     * @param socket  Used to close the socket connection
     * @param buffReader Used to close the reader Connection
     * @param buffWriter Used to close the writer
     */
    public static void closeConnection(Socket socket, BufferedReader buffReader, BufferedWriter buffWriter){
        try{
            if(socket!= null){
                socket.close();
            }
            if(buffReader != null) {
                buffReader.close();
            }
            if(buffWriter!= null){
                buffWriter.close();
            }

        }catch(IOException e){
            e.printStackTrace();
        }
    }




    /**
     * Main Method that handles the runtime of the program
     * Function: Will load the JFrame so that the user can type out to the screen and send messages.
     * Will attempt to connect to the server so that the client and send messages to the server and can receive
     * messages to the server.
     */
    public static void main(String[] args){
        clientSide mainFrame =  new clientSide("Client Side App");
        mainFrame.setVisible(true);
        try {

            //Attempts to establish a connection to the server, throws an exception if not possible.
            try {
                socket = new Socket("localhost",12345);
                buffReader = new BufferedReader( new InputStreamReader(socket.getInputStream()));
                buffWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
                dataOutputStream = new DataOutputStream(socket.getOutputStream());
                dataInputStream = new DataInputStream(socket.getInputStream());

            }catch(IOException e ) {
                e.printStackTrace();
                closeConnection(socket, buffReader,buffWriter);
            }

            //While the message from the server is not "null", update the receive the message from the client and update the chat box.
            String fromServer = "";
            while(!fromServer.equals("null")) {
                fromServer = buffReader.readLine();
                mainFrame.chatArea.setText(mainFrame.chatArea.getText().trim()+ "\n Server:\t" + fromServer );
            }




        } catch(IOException e){
            e.printStackTrace();
        }


    }


}

